export interface Icommunity {
    id:number
    commenter:string
    comment:string
}
