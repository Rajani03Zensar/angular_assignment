export interface Iweight {
    id:number    
    weight:number   
    date:string
    bodyfat:number
}
